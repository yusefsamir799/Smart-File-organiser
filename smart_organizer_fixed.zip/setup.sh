#!/usr/bin/env bash
# Smart File Organizer — one-step build & verify.
set -euo pipefail

echo "──────────────────────────────────────"
echo "  Smart File Organizer — Setup"
echo "──────────────────────────────────────"
echo

# 1. Check toolchain
if ! command -v cargo &>/dev/null; then
    echo "✗ Rust/Cargo not found."
    echo "  Install it:  curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh"
    exit 1
fi
echo "✓ Rust $(rustc --version | awk '{print $2}') detected"

# 2. Build
echo
echo "Building (release)…"
cargo build --release

echo
echo "──────────────────────────────────────"
echo "  Setup complete!"
echo "──────────────────────────────────────"
echo
echo "Quick start:"
echo
echo "  # 1. Preview first (always a good idea):"
echo "  cargo run --release -- --dry-run --path ~/Downloads"
echo
echo "  # 2. Do it for real:"
echo "  cargo run --release -- --path ~/Downloads"
echo
echo "  # 3. Check the log:"
echo "  cat organizer_log.txt"
echo
