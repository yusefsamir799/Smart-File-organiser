# How to Test

## Project Layout

```
src/
  lib.rs          ← all core logic (public API)
  main.rs         ← thin CLI wrapper
tests/
  integration.rs  ← all 24 tests live here
```

`lib.rs` holds everything testable. `main.rs` just parses CLI args and calls
into the library. The tests import `smart_organizer::*` and exercise the
public API without touching clap.

## Running Tests

```bash
# Run all 24 tests
cargo test

# See println! output (normally captured)
cargo test -- --nocapture

# Run a single test by name
cargo test sorts_by_extension

# Run tests matching a pattern
cargo test collision       # 4 collision tests
cargo test categorize      # 3 categorize tests
cargo test duplicate       # 2 duplicate tests
cargo test organize        # skips_junk, dry_run, keep_structure, etc.

# Run tests single-threaded (if the log test flakes)
cargo test -- --test-threads=1
```

## What Each Test Covers

### Config & Categorization (5 tests)

| Test | Checks |
|------|--------|
| `categorize_known_extensions` | jpg→Images, pdf→Documents, etc. |
| `categorize_is_case_insensitive` | JPG and jpg both match |
| `categorize_unknown_returns_none` | .xyz → None, not Some("Other") |
| `default_config_has_all_categories` | All 5 categories exist |
| `parse_valid_toml` | Custom TOML categories parse correctly |
| `empty_toml_falls_back_to_defaults` | Empty file → default categories |

### Junk Detection (3 tests)

| Test | Checks |
|------|--------|
| `detects_hidden_files` | .DS_Store, .gitignore flagged |
| `detects_os_junk` | Thumbs.db, desktop.ini flagged |
| `normal_files_are_not_junk` | photo.jpg passes through |

### Collision Resolution (4 tests)

| Test | Checks |
|------|--------|
| `no_collision_keeps_original_name` | No conflict → same name |
| `first_collision_appends_date` | → `photo_2026-02-11.jpg` |
| `second_collision_appends_v2` | → `photo_2026-02-11_v2.jpg` |
| `third_collision_appends_v3` | → `_v3` |

### File Collection (4 tests)

| Test | Checks |
|------|--------|
| `collects_recursively` | Finds files in nested dirs |
| `skips_category_folders` | Won't re-scan Images/ etc. |
| `skips_hidden_directories` | Ignores .git/ |
| `empty_dir_returns_empty_vec` | No crash on empty dir |

### File Moving (2 tests)

| Test | Checks |
|------|--------|
| `move_renames_and_removes_source` | Source gone, dest exists |
| `move_preserves_binary_content` | Byte-for-byte match |

### Full Pipeline (9 tests)

| Test | Checks |
|------|--------|
| `sorts_by_extension` | jpg→Images/, pdf→Documents/, mp3→Music/ |
| `skips_unknown_extensions` | .xyz stays, counted as skipped |
| `skips_junk_files` | .DS_Store not organized |
| `dry_run_moves_nothing` | Counted but files untouched |
| `handles_name_collision` | Dated rename on conflict |
| `keep_structure_preserves_subfolders` | vacation/photo.jpg → Images/vacation/photo.jpg |
| `creates_log_file` | organizer_log.txt written |
| `empty_directory_returns_zeros` | All stats are 0 |
| `extensionless_files_counted_as_skipped` | Makefile counted, not moved |

### Duplicate Detection (2 tests)

| Test | Checks |
|------|--------|
| `detects_duplicates_same_name_and_size` | Second copy flagged |
| `different_sizes_are_not_duplicates` | Both organized normally |

## Manual Smoke Test

```bash
# Create a playground
mkdir -p /tmp/test_organizer
cp ~/Downloads/*.jpg ~/Downloads/*.pdf /tmp/test_organizer/ 2>/dev/null

# Preview
cargo run --release -- --dry-run --path /tmp/test_organizer

# For real
cargo run --release -- --path /tmp/test_organizer

# Check
ls /tmp/test_organizer/
cat organizer_log.txt

# Clean up
rm -rf /tmp/test_organizer
```

## Troubleshooting

**Permission errors** → Make sure `/tmp` is writable.

**`creates_log_file` flakes** → It changes cwd. Run isolated:
`cargo test creates_log_file -- --test-threads=1`

**CI failures** → Ensure the runner has a writable temp directory and filesystem.
