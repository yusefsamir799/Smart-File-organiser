# Bugs Fixed & Changes Made

## Critical Bugs

### 1. Double-counting moved files
**Where:** `organize_files()`, lines 292 + 298  
**Problem:** `total_count += 1` appeared both *inside* the success branch of the
actual move **and** unconditionally after the entire `if dry_run / else` block.
Every successful move was counted twice; failed moves were still counted once.  
**Fix:** Single `stats.moved += 1` inside each branch, nowhere else.

### 2. `categorize_file()` could never return `None`
**Where:** `categorize_file()`, line 345  
**Problem:** The function returned `Option<String>` but the fallback was
`Some("Other".to_string())`, so the `Option` was meaningless — *every* file got
organized, even ones with exotic extensions the user didn't configure.  
**Fix:** Return `None` for unknown extensions. The caller now increments a
`skipped` counter and moves on, which is the realistic behavior.

### 3. `keyword_rules` parsed but never used
**Where:** `Config` struct, `keyword_rules` field  
**Problem:** The field existed in the TOML schema and was deserialized, but no
code ever read it. Dead code that misleads readers.  
**Fix:** Removed entirely. If keyword matching is needed, it belongs in the
"Pro" version.

### 4. Duplicate-detection registry silently overwrote entries
**Where:** `organize_files()`, line 200  
**Problem:** The HashMap key was `name_date`. When two files had the same name
and date but *different* sizes, the second one overwrote the first in the
registry, losing the record of the original. A later third file identical to the
first would not be detected as a duplicate.  
**Fix:** Changed the composite key to `name|date|size`, so entries are only
compared when all three match.

### 5. Hidden / OS junk files were organized
**Where:** `collect_files_recursive()` + main loop  
**Problem:** `.DS_Store`, `Thumbs.db`, `.gitignore`, and other hidden or OS
metadata files were happily sorted into category folders.  
**Fix:** Added `is_hidden_or_junk()` check that skips dotfiles, `Thumbs.db`,
`desktop.ini`, and the organizer's own log file. Hidden *directories* are also
skipped during traversal.

### 6. Files without extensions silently dropped
**Where:** main loop  
**Problem:** Files like `Makefile`, `LICENSE`, or `README` had no extension, so
the `if let Some(extension)` guard skipped them with zero feedback.  
**Fix:** Now counted as `stats.skipped` and reported in the summary.

---

## Code Quality Improvements

| Before | After | Why |
|--------|-------|-----|
| `fn move_file(from: &PathBuf, to: &PathBuf)` | `fn move_file(from: &Path, to: &Path)` | `&Path` is the idiomatic param type; `&PathBuf` is an unnecessary indirection. |
| Duplicate 8-line config fallback in `load_simple_config` | `Config::load()` with `Config::default()` | Single source of truth via `Default` trait impl. |
| `categorize_file` as a free function | `Config::categorize(&self, ext)` method | Behavior belongs on the type that owns the data. |
| `extension.to_string()` comparison in a loop | `eq_ignore_ascii_case` on `&str` | Avoids allocating a new `String` on every comparison. |
| Single `total_count: usize` | `Stats { moved, duplicates, skipped, errors }` | Fine-grained reporting instead of a single ambiguous number. |
| Raw `std::io::Error` bubbling | Same, but with `eprintln!` context at call sites | User sees *which file* failed, not just an OS error code. |
| `args.path` was a `String` | `args.path` is a `PathBuf` | Avoids repeated `Path::new(&args.path)` conversions. |
| No input validation | `!args.path.is_dir()` check at startup | Fail fast with a clear message instead of a cryptic read_dir error. |
| Collision counter started at `1` → `_v1` | Starts at `2` → `_v2` | The un-suffixed dated name is implicitly "v1", so the first collision suffix should be `_v2`. |

---

## Structural Changes

- **Removed** `BEGINNER_GUIDE.md`, `VERSION_COMPARISON.md`, `README_SMART.md` —
  these are documentation for the old version. Replace with your own README.
- **Renamed** CLI flag `--keep-source-structure` → `--keep-structure` (shorter).
- **Renamed** binary from `smart_file_organizer` → `smart-organizer`.
- **setup.sh** simplified: no more copying/renaming files. Standard Cargo layout
  (`src/main.rs`) is used directly.
